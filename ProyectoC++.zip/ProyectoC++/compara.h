/* 
 * File:   compara.h
 * Author: sama
 *
 * Created on June 1, 2014, 8:52 PM
 */

#ifndef COMPARA_H
#define	COMPARA_H

class compara {
public:
    compara();
    compara(const compara& orig);
    virtual ~compara();
    void sacapromedios();
    void arreglo_prom();
    
private:

};

#endif	/* COMPARA_H */

